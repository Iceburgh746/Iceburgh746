# WRCX212 Tweety Bird v1.0

Rebranded Quansheng-compatible radio firmware image.

## Included file

- `WRCX212_Tweety_Bird_v1.0_Rebranded.bin`

## Branding changes

- Main build label: `WRCX212 Tweety Bird v1.0`
- Compact build labels: `WRCX212 TB 1.0`
- Previous visible `v5.9.0` labels removed.

## Flashing

Flash only to the compatible radio model and bootloader you have verified. Back up the radio's calibration and original firmware first. This release has had structural and checksum validation only; test radio operation after flashing.

## Integrity

Verify the firmware SHA-256 against `SHA256SUMS.txt` before flashing.

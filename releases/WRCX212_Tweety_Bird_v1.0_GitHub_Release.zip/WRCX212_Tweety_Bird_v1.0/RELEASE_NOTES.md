# Release Notes — WRCX212 Tweety Bird v1.0

This release rebrands the supplied firmware's visible build/version text for WRCX212 Tweety Bird v1.0. It preserves the existing firmware code and replaces only verified embedded branding strings.

Known embedded feature labels retained from the supplied image include UV-K1 and UV-K5(8) model entries, GMRS/MURS text, TWEETY Roger selection, and AGC profiles.
